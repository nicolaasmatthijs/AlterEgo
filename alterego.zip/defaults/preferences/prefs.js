pref("extensions.alterego.boolpref", false);
pref("extensions.alterego.intpref", 0);
pref("extensions.alterego.stringpref", "A string");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.nm417@cam.ac.uk.description", "chrome://alterego/locale/overlay.properties");
